'use strict';
/* ===== Ajustes de texto (revisão pré-lançamento, nov/2026) =====
   Corrige textos exibidos ao aluno sem alterar a lógica do painel:
   aviso de vídeo pendente, aviso interno da Aula 1.1, plurais com parênteses,
   mensagem de doadores inativos sem cadastro e alerta de fim de ano.
   As mesmas trocas foram aplicadas na versão corrigida do código-fonte entregue com a revisão. */
(function(){
  const plural=(n,um,varios)=>Number(n)===1?um:varios;
  const trocas=[
    [/APRESENTAÇÃO DO CURSO/g,'COMO USAR O PAINEL'],
    [/^Bem-vindo ao Painel de Captação$/,'Leia a aula e aplique aqui'],
    [/Vídeo de apresentação aguardando o arquivo Cena 1\.mp4/g,'Cada ferramenta corresponde a uma aula do curso. Os dados ficam salvos só neste navegador: faça backup em Cadastro e Backup.'],
    [/^CURSO DE CAPTAÇÃO DE RECURSOS$/,'CURSO DE CAPTAÇÃO DE RECURSOS · COM MARIANA FERREIRA VELLOSO'],
    [/ A aula 1\.1 ainda não está cadastrada nesta plataforma\./g,' A Aula 1.1 é de leitura e reflexão, por isso não tem ferramenta no painel.'],
    [/O 4º trimestre concentra a maior generosidade do ano\./g,'Fim de ano é um período tradicional de campanhas solidárias: planeje com antecedência.'],
    [/Complete os (\d+) trecho\(s\)/g,(m,n)=>Number(n)===1?'Complete o trecho':`Complete os ${n} trechos`],
    [/(\d+) edital\(is\)/g,(m,n)=>`${n} ${plural(n,'edital','editais')}`],
    [/(\d+) oportunidade\(s\)/g,(m,n)=>`${n} ${plural(n,'oportunidade','oportunidades')}`],
    [/(\d+) doador\(es\) ativo\(s\)/g,(m,n)=>`${n} ${plural(n,'doador ativo','doadores ativos')}`],
    [/(\d+) doador\(es\)/g,(m,n)=>`${n} ${plural(n,'doador','doadores')}`],
    [/(\d+) dia\(s\)/g,(m,n)=>`${n} ${plural(n,'dia','dias')}`],
    [/(\d+) ano\(s\)/g,(m,n)=>`${n} ${plural(n,'ano','anos')}`]
  ];
  const semDoadores=()=>{try{return !(typeof S!=='undefined'&&S.doadores&&S.doadores.length)}catch(e){return true}};
  function corrigeTexto(t){
    let s=t;
    for(const [re,novo] of trocas){re.lastIndex=0;s=s.replace(re,novo)}
    if(s.indexOf('Nenhum doador inativo há 60+ dias.')>-1){
      s=semDoadores()?'Quando houver doadores cadastrados, quem estiver há 60 dias ou mais sem doar aparecerá aqui.':'Nenhum doador inativo há 60 dias ou mais.';
    }
    return s;
  }
  function corrige(raiz){
    if(!raiz)return;
    if(raiz.nodeType===3){const n=corrigeTexto(raiz.nodeValue);if(n!==raiz.nodeValue)raiz.nodeValue=n;return}
    if(raiz.nodeType!==1)return;
    const w=document.createTreeWalker(raiz,NodeFilter.SHOW_TEXT);
    let no;while((no=w.nextNode())){const n=corrigeTexto(no.nodeValue);if(n!==no.nodeValue)no.nodeValue=n}
    raiz.querySelectorAll&&raiz.querySelectorAll('.intro-video-mark').forEach(el=>{if(el.textContent.trim()==='🎬')el.textContent='✎'});
    raiz.querySelectorAll&&raiz.querySelectorAll('textarea').forEach(el=>{const n=corrigeTexto(el.value);if(n!==el.value)el.value=n});
  }
  function iniciar(){
    corrige(document.body);
    new MutationObserver(lista=>{for(const m of lista){
      if(m.type==='characterData')corrige(m.target);
      else m.addedNodes.forEach(corrige);
    }}).observe(document.body,{childList:true,subtree:true,characterData:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',iniciar);else iniciar();
})();
