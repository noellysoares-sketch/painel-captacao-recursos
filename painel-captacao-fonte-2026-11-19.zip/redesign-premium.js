/* UI premium: camada de apresentação; não migra nem modifica dados. */
(function(){
'use strict';
const safe=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=x=>(Number(x)||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL',maximumFractionDigits:0});
const navGroups=[
 ['PRINCIPAL',[['painel','Dashboard']]],
 ['MÓDULO 1 · DIAGNÓSTICO',[['fontes','Aula 1.2 · Mapa de Fontes'],['diagnostico','Aulas 1.3–1.5 · Diagnóstico']]],
 ['MÓDULO 2 · PLANEJAMENTO',[['plano','Aulas 2.1–2.2 · Plano e Metas'],['narrativa','Aulas 2.3–2.5 · Narrativa']]],
 ['MÓDULO 3 · CAPTAÇÃO',[['doadores','Aulas 3.1, 3.3 e 3.4 · Doadores'],['campanhas','Aulas 3.2 e 3.5 · Campanhas'],['mensagens','Mensagens Prontas']]],
 ['MÓDULO 4 · GESTÃO',[['funil','Funil de Captação'],['editais','Editais e Oportunidades'],['documentos','Documentos'],['prazos','Prazos']]],
 ['ACOMPANHAMENTO',[['mensal','Ritual Mensal'],['relatorios','Relatórios']]],
 ['MINHA ORGANIZAÇÃO',[['dados','Cadastro e Backup'],['configuracoes','Configurações']]]
];
ROTAS.splice(0,ROTAS.length,...navGroups);
/* Apresentação didática do curso: o vídeo inicial não tem arquivo público cadastrado. */
const introVideoUrl='';
const modules=[
 ['01','Diagnóstico e fontes','Identifique oportunidades de financiamento e avalie o nível de organização da sua instituição.','fontes','Mapa de fontes e diagnóstico'],
 ['02','Planejamento e narrativa','Defina objetivos, metas e organize uma apresentação clara da causa e dos resultados esperados.','plano','Plano, metas e narrativa'],
 ['03','Doadores e campanhas','Organize o relacionamento com apoiadores e desenvolva campanhas de captação.','doadores','Doadores, campanhas e mensagens'],
 ['04','Gestão e acompanhamento','Acompanhe oportunidades, documentos, editais, prazos e resultados.','funil','Funil, editais e documentos']
];
function cursoInicio(){
 const video=introVideoUrl?'<video controls preload="metadata" playsinline src="'+safe(introVideoUrl)+'" aria-label="Vídeo de apresentação do curso"></video>':
 '<div class="intro-video-await"><div class="intro-video-mark">🎬</div><span class="intro-video-overline">APRESENTAÇÃO DO CURSO</span><strong>Bem-vindo ao Painel de Captação</strong><p>Vídeo de apresentação aguardando o arquivo Cena 1.mp4</p></div>';
 return '<div class="course-home"><div class="course-home-hero"><div class="course-hero-copy"><span class="course-eyebrow">CURSO DE CAPTAÇÃO DE RECURSOS</span><h1>Aprenda a captar recursos e transforme o planejamento em ação.</h1><p>Conheça a jornada de aprendizagem, entenda os objetivos de cada módulo e aplique o conteúdo diretamente nas ferramentas do painel.</p><a class="course-primary" href="#fontes">Começar pelo Módulo 1 →</a></div><div class="course-hero-video">'+video+'</div></div>'+
 '<section class="course-home-section"><div class="course-section-heading"><span>O QUE VOCÊ VAI APRENDER</span><h2>Da identificação de oportunidades à gestão da captação</h2></div><div class="course-learning-grid">'+[
 ['◎','Diagnosticar','Avaliar a situação da organização e reconhecer necessidades de estruturação.'],
 ['◈','Planejar','Definir metas, fontes de recursos e uma narrativa institucional consistente.'],
 ['♡','Mobilizar','Estruturar relacionamento com doadores e ações de captação.'],
 ['▤','Monitorar','Organizar oportunidades, editais, documentos e resultados.']
 ].map(([icon,title,desc])=>'<article class="course-learning-item"><span>'+icon+'</span><h3>'+title+'</h3><p>'+desc+'</p></article>').join('')+'</div></section>'+
 '<section class="course-home-section"><div class="course-section-heading"><span>TRILHA DE APRENDIZAGEM</span><h2>Explore os quatro módulos do curso</h2><p>Comece pelo conteúdo introdutório de cada módulo e siga para as ferramentas práticas.</p></div><div class="course-module-grid">'+modules.map(([num,title,desc,route,tools])=>'<article class="course-module"><div class="course-module-top"><span>MÓDULO '+num+'</span><span class="course-module-arrow">↗</span></div><h3>'+title+'</h3><p>'+desc+'</p><div class="course-module-bottom"><small>'+tools+'</small><a href="#'+route+'">Abrir módulo →</a></div></article>').join('')+'</div></section>'+
 '<section class="course-home-end"><div><strong>Aprender e aplicar no mesmo lugar</strong><p>As atividades práticas permanecem disponíveis no menu lateral. O acompanhamento abaixo reflete os dados registrados neste navegador, não a conclusão de videoaulas.</p></div><a href="#dados">Minha organização →</a></section></div>';
}
const oldPainel=V.painel;
V.painel=()=>{
 const html=oldPainel();
 const next=html.indexOf('<div class="grid g2">');
 return cursoInicio()+(next>=0?html.slice(next):html);
};

V.relatorios=()=>{
 const P=planoCalc();
 const totalDocs=Array.isArray(S.docs)?S.docs.length:0;
 const pend=Array.isArray(S.docs)?S.docs.filter(x=>!x.ok).length:0;
 return '<div class="head"><div><span class="tag">GESTÃO</span><h1>Relatórios gerenciais</h1><p class="lead">Visão resumida dos dados cadastrados neste navegador.</p></div></div><div class="grid g3"><div class="kpi"><div class="l">Meta anual</div><div class="v">'+safe(P.obj?money(P.obj):'—')+'</div><div class="s">Planejamento informado</div></div><div class="kpi"><div class="l">Captação registrada</div><div class="v">'+safe(money(P.real))+'</div><div class="s">Receitas lançadas no painel</div></div><div class="kpi"><div class="l">Documentos pendentes</div><div class="v">'+pend+'</div><div class="s">De '+totalDocs+' documentos cadastrados</div></div></div><div class="card"><h2>Resumo e exportação</h2><p class="premium-small">Utilize Imprimir / Salvar como PDF para exportar o relatório. A confirmação financeira e documental deve ocorrer antes do compartilhamento.</p><div class="premium-settings-actions"><button class="btn" type="button" data-a="imprimir">Imprimir / Salvar em PDF</button><a class="btn sec" href="#mensal">Ver acompanhamento mensal</a></div></div>';
};
V.configuracoes=()=>'<div class="head"><div><span class="tag">CONFIGURAÇÕES</span><h1>Configurações do painel</h1><p class="lead">Preferências de utilização e orientações para preservar seus dados.</p></div></div><div class="card"><h2>Identidade visual</h2><p class="premium-small">Tema atual: Laranja Solar · Títulos: Plus Jakarta Sans · Textos: Inter.</p></div><div class="card"><h2>Privacidade e armazenamento</h2><p class="premium-small">Nesta versão, os dados da organização são armazenados somente neste navegador. Ainda não há login, sincronização entre aparelhos ou conexão real com IA. Faça backup regularmente.</p><div class="premium-settings-actions"><a class="btn" href="#dados">Meus dados e backup</a><a class="btn sec" href="#painel">Voltar ao Dashboard</a></div></div>';
const toggle=document.getElementById('menu-toggle');
const shade=document.getElementById('menu-shade');
const side=document.querySelector('.side');
function close(){document.body.classList.remove('menu-open');if(toggle){toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','Abrir menu')}if(shade)shade.hidden=true}
function open(){document.body.classList.add('menu-open');toggle.setAttribute('aria-expanded','true');toggle.setAttribute('aria-label','Fechar menu');shade.hidden=false;side.querySelector('a')?.focus()}
toggle?.addEventListener('click',()=>document.body.classList.contains('menu-open')?close():open());
shade?.addEventListener('click',close);
document.addEventListener('keydown',ev=>{if(ev.key==='Escape')close()});
document.getElementById('nav')?.addEventListener('click',ev=>{if(ev.target.closest('a'))close()});
window.addEventListener('hashchange',close);
window.addEventListener('resize',()=>{if(window.innerWidth>760)close()});
render();
})();