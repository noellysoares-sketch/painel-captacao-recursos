# Painel de Captação de Recursos

Cópia do código-fonte publicada em 19/11/2026, recuperada da versão de produção do projeto Vercel `painel-captacao`.

## Site oficial
https://painel-captacao-recursos.vercel.app/

## Estrutura
- `index.html`: entrada da aplicação
- `app.js` e `app.css`: lógica principal, aulas e atividades
- `redesign-premium.js` e `redesign-premium.css`: menu e layout do sistema
- `tema-laranja.css`: identidade visual
- `apresentacao-curso.css`: apresentação do curso
- `trilha-aulas.js`: navegação entre atividades
- `editais.js`: funcionalidades relacionadas a editais
- `ias-captacao.js`: componentes adicionais de captação
- `assistente-inteligente.js`: código de interface existente, não necessariamente IA conectada
- `ajustes-textos.js`: ajustes mais recentes da interface

## Execução local
O projeto atual é uma aplicação estática HTML/CSS/JavaScript. Abra `index.html` com um servidor estático HTTP, por exemplo `python -m http.server 8000`.

## GitHub / Vercel
Importe estes arquivos na raiz do repositório GitHub e conecte o repositório ao projeto EXISTENTE `painel-captacao` da Vercel. Não crie outro projeto de produção. Confirme a configuração de diretório raiz e o processo de build antes de promover novos deploys.

## Dados e limitações
O painel guarda dados no localStorage do navegador; eles não estão incluídos neste código-fonte. Não remova armazenamento nem altere chaves sem um plano de migração. Faça backup das informações do painel antes de alterações estruturais.

## Radar de Captação
O código do Radar não foi identificado como parte do pacote publicado. Integre a consultoria como nova seção/rota do menu, preservando as rotas e funcionalidades existentes e validando em prévia antes da produção.
