
/* Navegação progressiva da trilha do curso sem alterar conteúdo ou cálculos.
   A ordem respeita o menor número de aula apresentado em cada tela;
   algumas páginas reúnem aulas não consecutivas. */
(function(){
'use strict';
const stages=[
 ['fontes','1.2 · Mapa de fontes'],
 ['diagnostico','1.3–1.5 · Diagnóstico'],
 ['plano','2.1–2.2 · Plano e metas'],
 ['narrativa','2.3–2.5 · Narrativa'],
 ['doadores','3.1, 3.3 e 3.4 · Doadores'],
 ['campanhas','3.2 e 3.5 · Campanhas'],
 ['funil','4.1, 4.2 e 4.4 · Funil'],
 ['documentos','4.3 · Documentos'],
 ['prazos','4.3–4.4 · Prazos'],
 ['mensal','2.1 e 4.4 · Acompanhamento']
];
const escape=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
stages.forEach(([key],i)=>{
 const original=V[key];if(typeof original!=='function')return;
 V[key]=function(){
   const prev=stages[i-1],next=stages[i+1],html=original();
   const strip='<nav class="course-strip" aria-label="Navegação da sequência do curso"><span class="course-step">Etapa '+(i+1)+' de '+stages.length+'</span><div class="course-links">'+(prev?'<a href="#'+prev[0]+'" aria-label="Aula anterior: '+escape(prev[1])+'">← Anterior</a>':'<span class="course-disabled">Início da trilha</span>')+(next?'<a href="#'+next[0]+'" aria-label="Próxima aula: '+escape(next[1])+'">Próxima →</a>':'<a href="#painel">Voltar ao painel →</a>')+'</div></nav>';
   return strip+html+strip;
 };
});
render();
})();
